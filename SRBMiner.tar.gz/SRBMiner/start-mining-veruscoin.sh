#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm xdag --pool xdagmine.com:13654 --wallet IqhI/6XzAwIkeQBWaWwelLsuPh66OmOT.do --cpu-threads 3
